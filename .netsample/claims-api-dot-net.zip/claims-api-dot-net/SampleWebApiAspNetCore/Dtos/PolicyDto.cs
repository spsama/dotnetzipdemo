using System;
using System.ComponentModel.DataAnnotations;

namespace YourNamespace.DTOs
{
    public class PolicyDto
    {
        [Required]
        public string PolicyNumber { get; set; }

        [Required]
        public string PolicyholderName { get; set; }

        [Required]
        public DateTime StartDate { get; set; }

        [Required]
        public DateTime EndDate { get; set; }

        [Required]
        public decimal PremiumAmount { get; set; }
    }

    public class ServiceResult
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}