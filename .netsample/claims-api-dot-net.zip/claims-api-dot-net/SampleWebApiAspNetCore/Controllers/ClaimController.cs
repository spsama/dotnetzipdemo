﻿

using Microsoft.AspNetCore.Mvc;
using YourNamespace.DTOs;
using YourNamespace.Services;
using System.Threading.Tasks;

namespace YourNamespace.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ClaimsController : ControllerBase
    {
        private readonly IClaimsService _claimsService;

        public ClaimsController(IClaimsService claimsService)
        {
            _claimsService = claimsService;
        }

        /// <summary>
        /// This class represents the controller for handling claims in the API.
        /// </summary>
        /// <remarks>
        /// The ClaimsController class is responsible for capturing FNOL (First Notice of Loss) information through the API.
        /// It provides an endpoint for capturing FNOL data and forwarding it to the claims service for processing.
        /// </remarks>
        [ApiController]
        [Route("api/[controller]")]
        public class ClaimsController : ControllerBase
        {
            private readonly IClaimsService _claimsService;

            /// <summary>
            /// Initializes a new instance of the ClaimsController class.
            /// </summary>
            /// /// <param name="claimsService">The claims service used for processing FNOL data.</param>
            public ClaimsController(IClaimsService claimsService)
            {
                _claimsService = claimsService;
            }

            /// <summary>
            /// Endpoint to capture FNOL (First Notice of Loss) information.
            /// </summary>
            /// <param name="fnolDto">The FNOL data transfer object containing the FNOL information.</param>
            /// <returns>An action result indicating the outcome of the operation.</returns>
            /// <remarks>
            /// This endpoint receives FNOL data in the form of a JSON payload and validates it using the model state.
            /// If the data is valid, it is passed to the claims service for further processing.
            /// The endpoint returns an HTTP status code indicating the success or failure of the operation.
            /// </remarks>
            [HttpPost("fnol")]
            public async Task<IActionResult> CaptureFNOL([FromBody] FNOLDto fnolDto)
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                await _claimsService.AddFNOLAsync(fnolDto);
                return Ok();
            }
        }   /// /// }
    }
}