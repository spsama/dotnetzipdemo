using YourNamespace.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace YourNamespace.Repository
{
    public class PolicyRepository : IPolicyRepository
    {
        private readonly List<Policy> _policies = new List<Policy>();

        public async Task AddPolicyAsync(Policy policy)
        {
            policy.Id = _policies.Count + 1;
            _policies.Add(policy);
            await Task.CompletedTask;
        }

        public async Task<Policy> GetPolicyByIdAsync(int id)
        {
            var policy = _policies.FirstOrDefault(p => p.Id == id);
            return await Task.FromResult(policy);
        }

        public async Task<IEnumerable<Policy>> GetAllPoliciesAsync()
        {
            return await Task.FromResult(_policies);
        }

        public async Task UpdatePolicyAsync(Policy policy)
        {
            var existingPolicy = _policies.FirstOrDefault(p => p.Id == policy.Id);
            if (existingPolicy != null)
            {
                _policies.Remove(existingPolicy);
                _policies.Add(policy);
            }
            await Task.CompletedTask;
        }

        public async Task DeletePolicyAsync(int id)
        {
            var policy = _policies.FirstOrDefault(p => p.Id == id);
            if (policy != null)
            {
                _policies.Remove(policy);
            }
            await Task.CompletedTask;
        }
    }
}