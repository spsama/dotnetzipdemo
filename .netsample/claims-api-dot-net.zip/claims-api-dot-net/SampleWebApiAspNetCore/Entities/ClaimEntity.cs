using System;

namespace YourNamespace.Entities
{
    public class ClaimEntity
    {
        public int Id { get; set; }
        public Policyholder? Policyholder { get; set; }
        public IncidentDetails? IncidentDetails { get; set; }
        public PropertyInfo? PropertyInfo { get; set; }
        public VehicleInfo? VehicleInfo { get; set; }
        public InjuryDetails? InjuryDetails { get; set; }
    }

    public class Policyholder
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? PolicyNumber { get; set; }
        public string? ContactNumber { get; set; }
    }

    public class IncidentDetails
    {
        public int Id { get; set; }
        public DateTime DateOfIncident { get; set; }
        public string? Description { get; set; }
    }

    public class PropertyInfo
    {
        public int Id { get; set; }
        public string? Address { get; set; }
        public string? Description { get; set; }
    }

    public class VehicleInfo
    {
        public int Id { get; set; }
        public string? Make { get; set; }
        public string? Model { get; set; }
        public string? LicensePlate { get; set; }
    }

    public class InjuryDetails
    {
        public int Id { get; set; }
        public string? InjuredPersonName { get; set; }
        public string? InjuryDescription { get; set; }
    }
}