Imports System.ServiceModel
Imports DTOs
Imports Services

Namespace Controllers
    <ServiceContract()>
    Public Interface IClaimsController
        <OperationContract()>
        Function GetAllClaims() As List(Of ClaimDTO)

        <OperationContract()>
        Function GetClaimById(claimId As Integer) As ClaimDTO

        <OperationContract()>
        Sub AddClaim(claimDto As ClaimDTO)

        <OperationContract()>
        Sub UpdateClaim(claimDto As ClaimDTO)

        <OperationContract()>
        Sub DeleteClaim(claimId As Integer)
    End Interface

    Public Class ClaimsController
        Implements IClaimsController

        Private ReadOnly _claimService As IClaimService

        Public Sub New(claimService As IClaimService)
            _claimService = claimService
        End Sub

        Public Function GetAllClaims() As List(Of ClaimDTO) Implements IClaimsController.GetAllClaims
            Return _claimService.GetAllClaims()
        End Function

        Public Function GetClaimById(claimId As Integer) As ClaimDTO Implements IClaimsController.GetClaimById
            Return _claimService.GetClaimById(claimId)
        End Function

        Public Sub AddClaim(claimDto As ClaimDTO) Implements IClaimsController.AddClaim
            _claimService.AddClaim(claimDto)
        End Sub

        Public Sub UpdateClaim(claimDto As ClaimDTO) Implements IClaimsController.UpdateClaim
            _claimService.UpdateClaim(claimDto)
        End Sub

        Public Sub DeleteClaim(claimId As Integer) Implements IClaimsController.DeleteClaim
            _claimService.DeleteClaim(claimId)
        End Sub
    End Class
End Namespace