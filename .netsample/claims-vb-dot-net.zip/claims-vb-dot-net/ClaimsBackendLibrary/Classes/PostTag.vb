﻿Namespace Classes
    Public Class PostTag
        Public Property BlogId As Integer
        Public Property PostId As Integer
    End Class
End Namespace