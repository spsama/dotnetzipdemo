Imports Entities
Imports Repository
Imports DTOs

Namespace Services
    Public Interface IPolicyService
        Function GetAllPolicies() As List(Of PolicyDTO)
        Function GetPolicyById(policyId As Integer) As PolicyDTO
        Sub AddPolicy(policyDto As PolicyDTO)
        Sub UpdatePolicy(policyDto As PolicyDTO)
        Sub DeletePolicy(policyId As Integer)
    End Interface

    Public Class PolicyService
        Implements IPolicyService

        Private ReadOnly _policyRepository As IPolicyRepository

        Public Sub New(policyRepository As IPolicyRepository)
            _policyRepository = policyRepository
        End Sub

        Public Function GetAllPolicies() As List(Of PolicyDTO) Implements IPolicyService.GetAllPolicies
            Return _policyRepository.GetAllPolicies().Select(Function(p) New PolicyDTO With {
                .PolicyId = p.PolicyId,
                .PolicyNumber = p.PolicyNumber,
                .PolicyHolderName = p.PolicyHolderName,
                .PolicyAmount = p.PolicyAmount,
                .PolicyStartDate = p.PolicyStartDate,
                .PolicyEndDate = p.PolicyEndDate
            }).ToList()
        End Function

        Public Function GetPolicyById(policyId As Integer) As PolicyDTO Implements IPolicyService.GetPolicyById
            Dim policy = _policyRepository.GetPolicyById(policyId)
            If policy Is Nothing Then Return Nothing
            Return New PolicyDTO With {
                .PolicyId = policy.PolicyId,
                .PolicyNumber = policy.PolicyNumber,
                .PolicyHolderName = policy.PolicyHolderName,
                .PolicyAmount = policy.PolicyAmount,
                .PolicyStartDate = policy.PolicyStartDate,
                .PolicyEndDate = policy.PolicyEndDate
            }
        End Function

        Public Sub AddPolicy(policyDto As PolicyDTO) Implements IPolicyService.AddPolicy
            Dim policy = New Policy With {
                .PolicyId = policyDto.PolicyId,
                .PolicyNumber = policyDto.PolicyNumber,
                .PolicyHolderName = policyDto.PolicyHolderName,
                .PolicyAmount = policyDto.PolicyAmount,
                .PolicyStartDate = policyDto.PolicyStartDate,
                .PolicyEndDate = policyDto.PolicyEndDate
            }
            _policyRepository.AddPolicy(policy)
        End Sub

        Public Sub UpdatePolicy(policyDto As PolicyDTO) Implements IPolicyService.UpdatePolicy
            Dim policy = New Policy With {
                .PolicyId = policyDto.PolicyId,
                .PolicyNumber = policyDto.PolicyNumber,
                .PolicyHolderName = policyDto.PolicyHolderName,
                .PolicyAmount = policyDto.PolicyAmount,
                .PolicyStartDate = policyDto.PolicyStartDate,
                .PolicyEndDate = policyDto.PolicyEndDate
            }
            _policyRepository.UpdatePolicy(policy)
        End Sub

        Public Sub DeletePolicy(policyId As Integer) Implements IPolicyService.DeletePolicy
            _policyRepository.DeletePolicy(policyId)
        End Sub
    End Class
End Namespace