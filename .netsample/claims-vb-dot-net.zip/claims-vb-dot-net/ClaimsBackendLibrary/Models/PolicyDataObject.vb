Namespace DTOs
    Public Class PolicyDTO
        Public Property PolicyId As Integer
        Public Property PolicyNumber As String
        Public Property PolicyHolderName As String
        Public Property PolicyAmount As Decimal
        Public Property PolicyStartDate As DateTime
        Public Property PolicyEndDate As DateTime
    End Class
End Namespace