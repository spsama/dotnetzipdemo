Namespace DTOs
    Public Class ClaimDTO
        Public Property ClaimId As Integer
        Public Property PolicyNumber As String
        Public Property ClaimAmount As Decimal
        Public Property ClaimDate As DateTime
        Public Property Status As String
    End Class
End Namespace