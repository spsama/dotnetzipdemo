Imports Entities

Namespace Repository
    Public Interface IPolicyRepository
        Function GetAllPolicies() As List(Of Policy)
        Function GetPolicyById(policyId As Integer) As Policy
        Sub AddPolicy(policy As Policy)
        Sub UpdatePolicy(policy As Policy)
        Sub DeletePolicy(policyId As Integer)
    End Interface

    Public Class PolicyRepository
        Implements IPolicyRepository

        Private ReadOnly _policies As List(Of Policy) = New List(Of Policy)()

        Public Function GetAllPolicies() As List(Of Policy) Implements IPolicyRepository.GetAllPolicies
            Return _policies
        End Function

        Public Function GetPolicyById(policyId As Integer) As Policy Implements IPolicyRepository.GetPolicyById
            Return _policies.FirstOrDefault(Function(p) p.PolicyId = policyId)
        End Function

        Public Sub AddPolicy(policy As Policy) Implements IPolicyRepository.AddPolicy
            _policies.Add(policy)
        End Sub

        Public Sub UpdatePolicy(policy As Policy) Implements IPolicyRepository.UpdatePolicy
            Dim existingPolicy = GetPolicyById(policy.PolicyId)
            If existingPolicy IsNot Nothing Then
                existingPolicy.PolicyNumber = policy.PolicyNumber
                existingPolicy.PolicyHolderName = policy.PolicyHolderName
                existingPolicy.PolicyAmount = policy.PolicyAmount
                existingPolicy.PolicyStartDate = policy.PolicyStartDate
                existingPolicy.PolicyEndDate = policy.PolicyEndDate
            End If
        End Sub

        Public Sub DeletePolicy(policyId As Integer) Implements IPolicyRepository.DeletePolicy
            Dim policy = GetPolicyById(policyId)
            If policy IsNot Nothing Then
                _policies.Remove(policy)
            End If
        End Sub
    End Class
End Namespace