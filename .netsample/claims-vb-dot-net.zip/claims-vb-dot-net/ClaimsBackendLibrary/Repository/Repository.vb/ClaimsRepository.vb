Imports Entities

Namespace Repository
    Public Interface IClaimRepository
        Function GetAllClaims() As List(Of Claim)
        Function GetClaimById(claimId As Integer) As Claim
        Sub AddClaim(claim As Claim)
        Sub UpdateClaim(claim As Claim)
        Sub DeleteClaim(claimId As Integer)
    End Interface

    Public Class ClaimRepository
        Implements IClaimRepository

        Private ReadOnly _claims As List(Of Claim) = New List(Of Claim)()

        Public Function GetAllClaims() As List(Of Claim) Implements IClaimRepository.GetAllClaims
            Return _claims
        End Function

        Public Function GetClaimById(claimId As Integer) As Claim Implements IClaimRepository.GetClaimById
            Return _claims.FirstOrDefault(Function(c) c.ClaimId = claimId)
        End Function

        Public Sub AddClaim(claim As Claim) Implements IClaimRepository.AddClaim
            _claims.Add(claim)
        End Sub

        Public Sub UpdateClaim(claim As Claim) Implements IClaimRepository.UpdateClaim
            Dim existingClaim = GetClaimById(claim.ClaimId)
            If existingClaim IsNot Nothing Then
                existingClaim.PolicyNumber = claim.PolicyNumber
                existingClaim.ClaimAmount = claim.ClaimAmount
                existingClaim.ClaimDate = claim.ClaimDate
                existingClaim.Status = claim.Status
            End If
        End Sub

        Public Sub DeleteClaim(claimId As Integer) Implements IClaimRepository.DeleteClaim
            Dim claim = GetClaimById(claimId)
            If claim IsNot Nothing Then
                _claims.Remove(claim)
            End If
        End Sub
    End Class
End Namespace