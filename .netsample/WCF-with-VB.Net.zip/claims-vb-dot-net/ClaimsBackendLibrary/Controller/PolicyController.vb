Imports System.ServiceModel
Imports DTOs
Imports Services

Namespace Controllers
    <ServiceContract()>
    Public Interface IPolicyController
        <OperationContract()>
        Function GetAllPolicies() As List(Of PolicyDTO)

        <OperationContract()>
        Function GetPolicyById(policyId As Integer) As PolicyDTO

        <OperationContract()>
        Sub AddPolicy(policyDto As PolicyDTO)

        <OperationContract()>
        Sub UpdatePolicy(policyDto As PolicyDTO)

        <OperationContract()>
        Sub DeletePolicy(policyId As Integer)
    End Interface

    Public Class PolicyController
        Implements IPolicyController

        Private ReadOnly _policyService As IPolicyService

        Public Sub New(policyService As IPolicyService)
            _policyService = policyService
        End Sub

        Public Function GetAllPolicies() As List(Of PolicyDTO) Implements IPolicyController.GetAllPolicies
            Return _policyService.GetAllPolicies()
        End Function

        Public Function GetPolicyById(policyId As Integer) As PolicyDTO Implements IPolicyController.GetPolicyById
            Return _policyService.GetPolicyById(policyId)
        End Function

        Public Sub AddPolicy(policyDto As PolicyDTO) Implements IPolicyController.AddPolicy
            _policyService.AddPolicy(policyDto)
        End Sub

        Public Sub UpdatePolicy(policyDto As PolicyDTO) Implements IPolicyController.UpdatePolicy
            _policyService.UpdatePolicy(policyDto)
        End Sub

        Public Sub DeletePolicy(policyId As Integer) Implements IPolicyController.DeletePolicy
            _policyService.DeletePolicy(policyId)
        End Sub
    End Class
End Namespace