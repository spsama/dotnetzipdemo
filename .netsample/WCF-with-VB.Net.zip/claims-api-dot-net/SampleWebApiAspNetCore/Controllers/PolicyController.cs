﻿using Microsoft.AspNetCore.Mvc;
using YourNamespace.DTOs;
using YourNamespace.Services;
using System.Threading.Tasks;

namespace YourNamespace.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PolicyController : ControllerBase
    {
        private readonly IPolicyService _policyService;

        public PolicyController(IPolicyService policyService)
        {
            _policyService = policyService;
        }

        /// <summary>
        /// Endpoint to create a new policy.
        /// </summary>
        /// <param name="policyDto">The policy data transfer object containing the policy information.</param>
        /// <returns>An action result indicating the outcome of the operation.</returns>
        [HttpPost]
        public async Task<IActionResult> CreatePolicy([FromBody] PolicyDto policyDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = await _policyService.CreatePolicyAsync(policyDto);

            if (result.Success)
            {
                return Ok(result.Message);
            }

            return StatusCode(500, result.Message);
        }

        /// <summary>
        /// Endpoint to get a policy by ID.
        /// </summary>
        /// <param name="id">The ID of the policy.</param>
        /// <returns>The policy information.</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetPolicy(int id)
        {
            var policy = await _policyService.GetPolicyByIdAsync(id);

            if (policy == null)
            {
                return NotFound();
            }

            return Ok(policy);
        }

        /// <summary>
        /// Endpoint to update an existing policy.
        /// </summary>
        /// <param name="id">The ID of the policy to update.</param>
        /// <param name="policyDto">The policy data transfer object containing the updated policy information.</param>
        /// <returns>An action result indicating the outcome of the operation.</returns>
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePolicy(int id, [FromBody] PolicyDto policyDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = await _policyService.UpdatePolicyAsync(id, policyDto);

            if (result.Success)
            {
                return Ok(result.Message);
            }

            return StatusCode(500, result.Message);
        }

        /// <summary>
        /// Endpoint to delete a policy by ID.
        /// </summary>
        /// <param name="id">The ID of the policy to delete.</param>
        /// <returns>An action result indicating the outcome of the operation.</returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePolicy(int id)
        {
            var result = await _policyService.DeletePolicyAsync(id);

            if (result.Success)
            {
                return Ok(result.Message);
            }

            return StatusCode(500, result.Message);
        }
    }
}