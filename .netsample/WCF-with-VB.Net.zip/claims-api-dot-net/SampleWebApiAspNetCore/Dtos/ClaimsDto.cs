

using System;
using System.ComponentModel.DataAnnotations;

namespace YourNamespace.DTOs
{
    /// <summary>
    /// Data Transfer Object for FNOL.
    /// </summary>
    /// <remarks>
    /// This class represents a Data Transfer Object (DTO) used for FNOL (First Notice of Loss) in an insurance claims system.
    /// It contains properties that represent various information related to a claim, such as policyholder name, contact information, policy number, incident date, incident description, property address, property description, vehicle details, and injured person details.
    /// </remarks>
    public class FNOLDto
    {
        /// <summary>
        /// Gets or sets the policyholder's name.
        /// </summary>
        /// /// <value>The policyholder's name.</value>
        ///         [Required]
        public string? PolicyholderName { get; set; }

        /// <summary>
        /// Gets or sets the contact information of the policyholder.
        /// </summary>
        /// <value>The contact information of the policyholder.</value>
        [Required]
        public string? ContactInformation { get; set; }

        /// <summary>
        /// Gets or sets the policy number associated with the claim.
        /// </summary>
        /// <value>The policy number associated with the claim.</value>
        [Required]
        public string? PolicyNumber { get; set; }

        /// <summary>
        /// Gets or sets the date of the incident.
        /// </summary>
        /// <value>The date of the incident.</value>
        [Required]
        public DateTime IncidentDate { get; set; }

        /// <summary>
        /// Gets or sets the description of the incident.
        /// </summary>
        /// <value>The description of the incident.</value>
        [Required]
        public string? IncidentDescription { get; set; }

        /// <summary>
        /// Gets or sets the address of the property involved in the incident.
        /// </summary>
        /// <value>The address of the property involved in the incident.</value>
        public string? PropertyAddress { get; set; }

        /// <summary>
        /// Gets or sets the description of the property involved in the incident.
        /// </summary>
        /// <value>The description of the property involved in the incident.</value>
        public string? PropertyDescription { get; set; }

        /// <summary>
        /// Gets or sets the make of the vehicle involved in the incident.
        /// </summary>
        /// <value>The make of the vehicle involved in the incident.</value>
        public string? VehicleMake { get; set; }

        /// <summary>
        /// Gets or sets the model of the vehicle involved in the incident.
        /// </summary>
        /// <value>The model of the vehicle involved in the incident.</value>
        public string? VehicleModel { get; set; }

        /// <summary>
        /// Gets or sets the license plate of the vehicle involved in the incident.
        /// </summary>
        /// <value>The license plate of the vehicle involved in the incident.</value>
        public string? VehicleLicensePlate { get; set; }

        /// <summary>
        /// Gets or sets the name of the injured person.
        /// </summary>
        /// <value>The name of the injured person.</value>
        public string? InjuredPersonName { get; set; }

        /// <summary>
        /// Gets or sets the description of the injury.
        /// </summary>
        /// <value>The description of the injury.</value>
        public string? InjuryDescription { get; set; }
    }  /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// /// }
}