using YourNamespace.Entities;
using System.Collections.Generic;
using YourNamespace.Services;

namespace YourNamespace.Repository
{
    public interface IClaimsRepository
    {
        void AddFNOL(FNOL fnol);
        FNOL GetFNOL(int id);
        IEnumerable<FNOL> GetAllFNOLs();
    
    }

    public class ClaimsRepository : IClaimsRepository
    {
        private readonly List<FNOL> _fnolList = new List<FNOL>();

        public void AddFNOL(FNOL fnol)
        {
            _fnolList.Add(fnol);
        }

        public FNOL GetFNOL(int id)
        {
#pragma warning disable CS8603 // Possible null reference return.
            return _fnolList.Find(f => f.Id == id);
#pragma warning restore CS8603 // Possible null reference return.
        }

        public IEnumerable<FNOL> GetAllFNOLs()
        {
            return _fnolList;
        }
    }
}