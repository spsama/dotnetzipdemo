using AutoMapper;
using YourNamespace.DTOs;
using YourNamespace.Entities;
using YourNamespace.Repository;
using System.Threading.Tasks;

namespace YourNamespace.Services
{
    public class PolicyService : IPolicyService
    {
        private readonly IPolicyRepository _policyRepository;
        private readonly IMapper _mapper;

        public PolicyService(IPolicyRepository policyRepository, IMapper mapper)
        {
            _policyRepository = policyRepository;
            _mapper = mapper;
        }

        public async Task<ServiceResult> CreatePolicyAsync(PolicyDto policyDto)
        {
            var policy = _mapper.Map<Policy>(policyDto);
            await _policyRepository.AddPolicyAsync(policy);
            return new ServiceResult { Success = true, Message = "Policy created successfully" };
        }

        public async Task<PolicyDto> GetPolicyByIdAsync(int id)
        {
            var policy = await _policyRepository.GetPolicyByIdAsync(id);
            return _mapper.Map<PolicyDto>(policy);
        }

        public async Task<ServiceResult> UpdatePolicyAsync(int id, PolicyDto policyDto)
        {
            var policy = _mapper.Map<Policy>(policyDto);
            policy.Id = id;
            await _policyRepository.UpdatePolicyAsync(policy);
            return new ServiceResult { Success = true, Message = "Policy updated successfully" };
        }

        public async Task<ServiceResult> DeletePolicyAsync(int id)
        {
            await _policyRepository.DeletePolicyAsync(id);
            return new ServiceResult { Success = true, Message = "Policy deleted successfully" };
        }
    }
}