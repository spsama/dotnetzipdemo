using YourNamespace.DTOs;
using YourNamespace.Entities; // Add this line if FNOL is defined in Entities namespace

using YourNamespace.Entities;
using YourNamespace.Repository;
using static YourNamespace.Services.FNOLRequestDto;

namespace YourNamespace.Services


{
    public interface IClaimsService
    {
        ServiceResult HandleFNOL(FNOLRequestDto fnolRequest);
    }

    public class FNOLRequestDto
    {
        public PolicyholderDto? Policyholder { get; internal set; }
        public IncidentDetailsDto? IncidentDetails { get; internal set; }
        public InjuryDetailsDto? InjuryDetails { get; internal set; }
        public PropertyInfoDto? PropertyInfo { get; internal set; }
        public VehicleInfoDto? VehicleInfo { get; internal set; }

        public class InjuryDetailsDto
        {
            public string? InjuryDescription { get; internal set; }
            public string? InjuredPersonName { get; internal set; }
        }
    }

    public class VehicleInfoDto
    {
        public string? Make { get; internal set; }
        public string? Model { get; internal set; }
        public string? LicensePlate { get; internal set; }
    }

    public class PolicyholderDto
    {
        public string? Name { get; internal set; }
        public string? PolicyNumber { get; internal set; }
        public string? ContactNumber { get; internal set; }
    }

    public class IncidentDetailsDto
    {
        public DateTime DateOfIncident { get; internal set; }
        public string? Description { get; internal set; }
    }

    public class PropertyInfoDto
    {
        public string? Address { get; set; }
        public string? Description { get; set; }
    }

    public class ClaimsService : IClaimsService
    {
        private readonly IClaimsRepository _claimsRepository;

        public ClaimsService(IClaimsRepository claimsRepository)
        {
            _claimsRepository = claimsRepository;
        }

        public Policyholder Policyholder { get; private set; }
        public IncidentDetails IncidentDetails { get; private set; }

        public ServiceResult HandleFNOL(FNOLRequestDto fnolRequest)
        {
            var fnol = new FNOL
            {
                Policyholder = new Policyholder
                {
                    Name = fnolRequest.Policyholder.Name,
                    PolicyNumber = fnolRequest.Policyholder.PolicyNumber,
                    ContactNumber = fnolRequest.Policyholder.ContactNumber
                },
                IncidentDetails = new IncidentDetails
                {
                    DateOfIncident = ((IncidentDetailsDto)fnolRequest.IncidentDetails).DateOfIncident,
                    Description = fnolRequest.IncidentDetails.Description
                },
                PropertyInfo = fnolRequest.PropertyInfo != null ? new PropertyInfo
                {
                    Address = fnolRequest.PropertyInfo.Address,
                    Description = fnolRequest.PropertyInfo.Description
                } : null,
                VehicleInfo = fnolRequest.VehicleInfo != null ? new VehicleInfo
                {
                    Make = fnolRequest.VehicleInfo.Make,
                    Model = fnolRequest.VehicleInfo.Model,
                    LicensePlate = fnolRequest.VehicleInfo.LicensePlate
                } : null,
                InjuryDetails = fnolRequest.InjuryDetails != null ? new InjuryDetails
                {
                    InjuredPersonName = ((InjuryDetailsDto)fnolRequest.InjuryDetails).InjuredPersonName,
                    InjuryDescription = fnolRequest.InjuryDetails.InjuryDescription
                } : null
            };

            _claimsRepository.AddFNOL(fnol); // or _claimsRepository.AddUrgentFNOL(fnol) if it is urgent

            return new ServiceResult { Success = true, Message = "FNOL submitted successfully" };
        }
    }

    }
    
    public class FNOL
    {
        public Policyholder? Policyholder { get; set; }
        public IncidentDetails? IncidentDetails { get; set; }
        public PropertyInfo? PropertyInfo { get; set; }
        public VehicleInfo? VehicleInfo { get; set; }
        public InjuryDetails? InjuryDetails { get; set; }
    public int Id { get; internal set; }
}

    public class ServiceResult
    {
        public bool Success { get; set; }
        public string? Message { get; set; }
    }

