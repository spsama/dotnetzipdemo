using YourNamespace.DTOs;
using System.Threading.Tasks;

namespace YourNamespace.Services
{
    public interface IPolicyService
    {
        Task<ServiceResult> CreatePolicyAsync(PolicyDto policyDto);
        Task<PolicyDto> GetPolicyByIdAsync(int id);
        Task<ServiceResult> UpdatePolicyAsync(int id, PolicyDto policyDto);
        Task<ServiceResult> DeletePolicyAsync(int id);
    }
}